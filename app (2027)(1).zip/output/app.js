(function (lwc) {
    'use strict';

    /**
     * Copyright (C) 2018 salesforce.com, inc.
     */

    /**
     * Copyright (C) 2018 salesforce.com, inc.
     */

    /*
     * Copyright (c) 2018, salesforce.com, inc.
     * All rights reserved.
     * SPDX-License-Identifier: MIT
     * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
     */
    function invariant(value, msg) {
      if (!value) {
        throw new Error(`Invariant Violation: ${msg}`);
      }
    }

    function isTrue(value, msg) {
      if (!value) {
        throw new Error(`Assert Violation: ${msg}`);
      }
    }

    function isFalse(value, msg) {
      if (value) {
        throw new Error(`Assert Violation: ${msg}`);
      }
    }

    function fail(msg) {
      throw new Error(msg);
    }

    var assert =
    /*#__PURE__*/
    Object.freeze({
      invariant: invariant,
      isTrue: isTrue,
      isFalse: isFalse,
      fail: fail
    });
    /*
     * Copyright (c) 2018, salesforce.com, inc.
     * All rights reserved.
     * SPDX-License-Identifier: MIT
     * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
     */

    /**
     * In IE11, symbols are expensive.
     * Due to the nature of the symbol polyfill. This method abstract the
     * creation of symbols, so we can fallback to string when native symbols
     * are not supported. Note that we can't use typeof since it will fail when transpiling.
     */

    const hasNativeSymbolsSupport = Symbol('x').toString() === 'Symbol(x)';
    /** version: 1.1.13-224.7 */

    /*
     * Copyright (c) 2018, salesforce.com, inc.
     * All rights reserved.
     * SPDX-License-Identifier: MIT
     * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
     */
    // key in engine service context for wire service context

    const CONTEXT_ID = '@wire'; // key in wire service context for updated listener metadata

    const CONTEXT_UPDATED = 'updated'; // key in wire service context for connected listener metadata

    const CONTEXT_CONNECTED = 'connected'; // key in wire service context for disconnected listener metadata

    const CONTEXT_DISCONNECTED = 'disconnected'; // wire event target life cycle connectedCallback hook event type

    const CONNECT = 'connect'; // wire event target life cycle disconnectedCallback hook event type

    const DISCONNECT = 'disconnect'; // wire event target life cycle config changed hook event type

    const CONFIG = 'config';
    /*
     * Copyright (c) 2018, salesforce.com, inc.
     * All rights reserved.
     * SPDX-License-Identifier: MIT
     * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
     */

    /*
     * Detects property changes by installing setter/getter overrides on the component
     * instance.
     *
     * TODO - in 216 engine will expose an 'updated' callback for services that is invoked
     * once after all property changes occur in the event loop.
     */

    /**
     * Invokes the provided change listeners with the resolved component properties.
     * @param configListenerMetadatas List of config listener metadata (config listeners and their context)
     * @param paramValues Values for all wire adapter config params
     */

    function invokeConfigListeners(configListenerMetadatas, paramValues) {
      configListenerMetadatas.forEach(metadata => {
        const {
          listener,
          statics,
          reactives
        } = metadata;
        const reactiveValues = Object.create(null);

        if (reactives) {
          const keys = Object.keys(reactives);

          for (let j = 0, jlen = keys.length; j < jlen; j++) {
            const key = keys[j];
            const value = paramValues[reactives[key]];
            reactiveValues[key] = value;
          }
        } // TODO - consider read-only membrane to enforce invariant of immutable config


        const config = Object.assign({}, statics, reactiveValues);
        listener.call(undefined, config);
      });
    }
    /**
     * Marks a reactive parameter as having changed.
     * @param cmp The component
     * @param reactiveParameter Reactive parameter that has changed
     * @param configContext The service context
     */


    function updated(cmp, reactiveParameter, configContext) {
      if (!configContext.mutated) {
        configContext.mutated = new Set(); // collect all prop changes via a microtask

        Promise.resolve().then(updatedFuture.bind(undefined, cmp, configContext));
      }

      configContext.mutated.add(reactiveParameter);
    }

    function updatedFuture(cmp, configContext) {
      const uniqueListeners = new Set(); // configContext.mutated must be set prior to invoking this function

      const mutated = configContext.mutated;
      delete configContext.mutated;
      mutated.forEach(reactiveParameter => {
        const value = getReactiveParameterValue(cmp, reactiveParameter);

        if (configContext.values[reactiveParameter.reference] === value) {
          return;
        }

        configContext.values[reactiveParameter.reference] = value;
        const listeners = configContext.listeners[reactiveParameter.head];

        for (let i = 0, len = listeners.length; i < len; i++) {
          uniqueListeners.add(listeners[i]);
        }
      });
      invokeConfigListeners(uniqueListeners, configContext.values);
    }
    /**
     * Gets the value of an @wire reactive parameter.
     * @param cmp The component
     * @param reactiveParameter The parameter to get
     */


    function getReactiveParameterValue(cmp, reactiveParameter) {
      let value = cmp[reactiveParameter.head];

      if (!reactiveParameter.tail) {
        return value;
      }

      const segments = reactiveParameter.tail;

      for (let i = 0, len = segments.length; i < len && value != null; i++) {
        const segment = segments[i];

        if (typeof value !== 'object' || !(segment in value)) {
          return undefined;
        }

        value = value[segment];
      }

      return value;
    }
    /**
     * Installs setter override to trap changes to a property, triggering the config listeners.
     * @param cmp The component
     * @param reactiveParameter Reactive parameter that defines the property to monitor
     * @param configContext The service context
     */


    function installTrap(cmp, reactiveParameter, configContext) {
      const callback = updated.bind(undefined, cmp, reactiveParameter, configContext);
      const newDescriptor = getOverrideDescriptor(cmp, reactiveParameter.head, callback);
      Object.defineProperty(cmp, reactiveParameter.head, newDescriptor);
    }
    /**
     * Finds the descriptor of the named property on the prototype chain
     * @param target The target instance/constructor function
     * @param propName Name of property to find
     * @param protoSet Prototypes searched (to avoid circular prototype chains)
     */


    function findDescriptor(target, propName, protoSet) {
      protoSet = protoSet || [];

      if (!target || protoSet.indexOf(target) > -1) {
        return null; // null, undefined, or circular prototype definition
      }

      const descriptor = Object.getOwnPropertyDescriptor(target, propName);

      if (descriptor) {
        return descriptor;
      }

      const proto = Object.getPrototypeOf(target);

      if (!proto) {
        return null;
      }

      protoSet.push(target);
      return findDescriptor(proto, propName, protoSet);
    }
    /**
     * Gets a property descriptor that monitors the provided property for changes
     * @param cmp The component
     * @param prop The name of the property to be monitored
     * @param callback A function to invoke when the prop's value changes
     * @return A property descriptor
     */


    function getOverrideDescriptor(cmp, prop, callback) {
      const descriptor = findDescriptor(cmp, prop);
      let enumerable;
      let get;
      let set; // This does not cover the override of existing descriptors at the instance level
      // and that's ok because eventually we will not need to do any of these :)

      if (descriptor === null || descriptor.get === undefined && descriptor.set === undefined) {
        let value = cmp[prop];
        enumerable = true;

        get = function () {
          return value;
        };

        set = function (newValue) {
          value = newValue;
          callback();
        };
      } else {
        const {
          set: originalSet,
          get: originalGet
        } = descriptor;
        enumerable = descriptor.enumerable;

        set = function (newValue) {
          if (originalSet) {
            originalSet.call(cmp, newValue);
          }

          callback();
        };

        get = function () {
          return originalGet ? originalGet.call(cmp) : undefined;
        };
      }

      return {
        set,
        get,
        enumerable,
        configurable: true
      };
    }
    /*
     * Copyright (c) 2018, salesforce.com, inc.
     * All rights reserved.
     * SPDX-License-Identifier: MIT
     * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
     */


    const ValueChangedEventType = 'ValueChangedEvent';
    /**
     * Event fired by wire adapters to emit a new value.
     */

    class ValueChangedEvent {
      constructor(value) {
        this.type = ValueChangedEventType;
        this.value = value;
      }

    }
    /*
     * Copyright (c) 2018, salesforce.com, inc.
     * All rights reserved.
     * SPDX-License-Identifier: MIT
     * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
     */


    const LinkContextEventType = 'LinkContextEvent';
    /**
     * Event fired by wire adapters to link to a context provider
     */

    class LinkContextEvent {
      constructor(uid, callback) {
        this.type = LinkContextEventType;
        this.uid = uid;
        this.callback = callback;
      }

    }
    /*
     * Copyright (c) 2018, salesforce.com, inc.
     * All rights reserved.
     * SPDX-License-Identifier: MIT
     * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
     */


    function removeListener(listeners, toRemove) {
      const idx = listeners.indexOf(toRemove);

      if (idx > -1) {
        listeners.splice(idx, 1);
      }
    }

    function removeConfigListener(configListenerMetadatas, toRemove) {
      for (let i = 0, len = configListenerMetadatas.length; i < len; i++) {
        if (configListenerMetadatas[i].listener === toRemove) {
          configListenerMetadatas.splice(i, 1);
          return;
        }
      }
    }

    function buildReactiveParameter(reference) {
      if (!reference.includes('.')) {
        return {
          reference,
          head: reference
        };
      }

      const segments = reference.split('.');
      return {
        reference,
        head: segments.shift(),
        tail: segments
      };
    }

    class WireEventTarget {
      constructor(cmp, def, context, wireDef, wireTarget) {
        this._cmp = cmp;
        this._def = def;
        this._context = context;
        this._wireDef = wireDef;
        this._wireTarget = wireTarget;
      }

      addEventListener(type, listener) {
        switch (type) {
          case CONNECT:
            {
              const connectedListeners = this._context[CONTEXT_ID][CONTEXT_CONNECTED];

              if (process.env.NODE_ENV !== 'production') {
                assert.isFalse(connectedListeners.includes(listener), 'must not call addEventListener("connect") with the same listener');
              }

              connectedListeners.push(listener);
              break;
            }

          case DISCONNECT:
            {
              const disconnectedListeners = this._context[CONTEXT_ID][CONTEXT_DISCONNECTED];

              if (process.env.NODE_ENV !== 'production') {
                assert.isFalse(disconnectedListeners.includes(listener), 'must not call addEventListener("disconnect") with the same listener');
              }

              disconnectedListeners.push(listener);
              break;
            }

          case CONFIG:
            {
              const reactives = this._wireDef.params;
              const statics = this._wireDef.static;
              let reactiveKeys; // no reactive parameters. fire config once with static parameters (if present).

              if (!reactives || (reactiveKeys = Object.keys(reactives)).length === 0) {
                const config = statics || Object.create(null);
                listener.call(undefined, config);
                return;
              }

              const configListenerMetadata = {
                listener,
                statics,
                reactives
              }; // setup listeners for all reactive parameters

              const configContext = this._context[CONTEXT_ID][CONTEXT_UPDATED];
              reactiveKeys.forEach(key => {
                const reactiveParameter = buildReactiveParameter(reactives[key]);
                let configListenerMetadatas = configContext.listeners[reactiveParameter.head];

                if (!configListenerMetadatas) {
                  configListenerMetadatas = [configListenerMetadata];
                  configContext.listeners[reactiveParameter.head] = configListenerMetadatas;
                  installTrap(this._cmp, reactiveParameter, configContext);
                } else {
                  configListenerMetadatas.push(configListenerMetadata);
                } // enqueue to pickup default values


                updated(this._cmp, reactiveParameter, configContext);
              });
              break;
            }

          default:
            throw new Error(`unsupported event type ${type}`);
        }
      }

      removeEventListener(type, listener) {
        switch (type) {
          case CONNECT:
            {
              const connectedListeners = this._context[CONTEXT_ID][CONTEXT_CONNECTED];
              removeListener(connectedListeners, listener);
              break;
            }

          case DISCONNECT:
            {
              const disconnectedListeners = this._context[CONTEXT_ID][CONTEXT_DISCONNECTED];
              removeListener(disconnectedListeners, listener);
              break;
            }

          case CONFIG:
            {
              const paramToConfigListenerMetadata = this._context[CONTEXT_ID][CONTEXT_UPDATED].listeners;
              const reactives = this._wireDef.params;

              if (reactives) {
                Object.keys(reactives).forEach(key => {
                  const reactiveParameter = buildReactiveParameter(reactives[key]);
                  const configListenerMetadatas = paramToConfigListenerMetadata[reactiveParameter.head];

                  if (configListenerMetadatas) {
                    removeConfigListener(configListenerMetadatas, listener);
                  }
                });
              }

              break;
            }

          default:
            throw new Error(`unsupported event type ${type}`);
        }
      }

      dispatchEvent(evt) {
        if (evt instanceof ValueChangedEvent) {
          const value = evt.value;

          if (this._wireDef.method) {
            this._cmp[this._wireTarget](value);
          } else {
            this._cmp[this._wireTarget] = value;
          }

          return false; // canceling signal since we don't want this to propagate
        } else if (evt instanceof LinkContextEvent) {
          const {
            uid,
            callback
          } = evt; // This event is responsible for connecting the host element with another
          // element in the composed path that is providing contextual data. The provider
          // must be listening for a special dom event with the name corresponding to `uid`,
          // which must remain secret, to guarantee that the linkage is only possible via
          // the corresponding wire adapter.

          const internalDomEvent = new CustomEvent(uid, {
            bubbles: true,
            composed: true,

            // avoid leaking the callback function directly to prevent a side channel
            // during the linking phase to the context provider.
            detail(...args) {
              callback(...args);
            }

          });

          this._cmp.dispatchEvent(internalDomEvent);

          return false; // canceling signal since we don't want this to propagate
        } else if (evt.type === 'WireContextEvent') {
          // TODO: issue #1357 - remove this branch
          return this._cmp.dispatchEvent(evt);
        } else {
          throw new Error(`Invalid event ${evt}.`);
        }
      }

    }
    /*
     * Copyright (c) 2018, salesforce.com, inc.
     * All rights reserved.
     * SPDX-License-Identifier: MIT
     * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/MIT
     */
    // wire adapters: wire adapter id => adapter ctor


    const adapterFactories = new Map();
    /**
     * Invokes the specified callbacks.
     * @param listeners functions to call
     */

    function invokeListener(listeners) {
      for (let i = 0, len = listeners.length; i < len; ++i) {
        listeners[i].call(undefined);
      }
    }
    /**
     * The wire service.
     *
     * This service is registered with the engine's service API. It connects service
     * callbacks to wire adapter lifecycle events.
     */


    const wireService = {
      wiring: (cmp, data, def, context) => {
        const wireContext = context[CONTEXT_ID] = Object.create(null);
        wireContext[CONTEXT_CONNECTED] = [];
        wireContext[CONTEXT_DISCONNECTED] = [];
        wireContext[CONTEXT_UPDATED] = {
          listeners: {},
          values: {}
        }; // engine guarantees invocation only if def.wire is defined

        const wireStaticDef = def.wire;
        const wireTargets = Object.keys(wireStaticDef);

        for (let i = 0, len = wireTargets.length; i < len; i++) {
          const wireTarget = wireTargets[i];
          const wireDef = wireStaticDef[wireTarget];
          const adapterFactory = adapterFactories.get(wireDef.adapter);

          if (process.env.NODE_ENV !== 'production') {
            assert.isTrue(wireDef.adapter, `@wire on "${wireTarget}": adapter id must be truthy`);
            assert.isTrue(adapterFactory, `@wire on "${wireTarget}": unknown adapter id: ${String(wireDef.adapter)}`); // enforce restrictions of reactive parameters

            if (wireDef.params) {
              Object.keys(wireDef.params).forEach(param => {
                const prop = wireDef.params[param];
                const segments = prop.split('.');
                segments.forEach(segment => {
                  assert.isTrue(segment.length > 0, `@wire on "${wireTarget}": reactive parameters must not be empty`);
                });
                assert.isTrue(segments[0] !== wireTarget, `@wire on "${wireTarget}": reactive parameter "${segments[0]}" must not refer to self`); // restriction for dot-notation reactive parameters

                if (segments.length > 1) {
                  // @wire emits a stream of immutable values. an emit sets the target property; it does not mutate a previously emitted value.
                  // restricting dot-notation reactive parameters to reference other @wire targets makes trapping the 'head' of the parameter
                  // sufficient to observe the value change.
                  assert.isTrue(wireTargets.includes(segments[0]) && wireStaticDef[segments[0]].method !== 1, `@wire on "${wireTarget}": dot-notation reactive parameter "${prop}" must refer to a @wire property`);
                }
              });
            }
          }

          if (adapterFactory) {
            const wireEventTarget = new WireEventTarget(cmp, def, context, wireDef, wireTarget);
            adapterFactory({
              dispatchEvent: wireEventTarget.dispatchEvent.bind(wireEventTarget),
              addEventListener: wireEventTarget.addEventListener.bind(wireEventTarget),
              removeEventListener: wireEventTarget.removeEventListener.bind(wireEventTarget)
            });
          }
        }
      },
      connected: (cmp, data, def, context) => {
        let listeners;

        if (process.env.NODE_ENV !== 'production') {
          assert.isTrue(!def.wire || context[CONTEXT_ID], 'wire service was not initialized prior to component creation:  "connected" service hook invoked without necessary context');
        }

        if (!def.wire || !(listeners = context[CONTEXT_ID][CONTEXT_CONNECTED])) {
          return;
        }

        invokeListener(listeners);
      },
      disconnected: (cmp, data, def, context) => {
        let listeners;

        if (process.env.NODE_ENV !== 'production') {
          assert.isTrue(!def.wire || context[CONTEXT_ID], 'wire service was not initialized prior to component creation:  "disconnected" service hook invoked without necessary context');
        }

        if (!def.wire || !(listeners = context[CONTEXT_ID][CONTEXT_DISCONNECTED])) {
          return;
        }

        invokeListener(listeners);
      }
    };
    /**
     * Registers the wire service.
     */

    function registerWireService(registerService) {
      registerService(wireService);
    }
    /** version: 1.1.13-224.7 */

    function stylesheet(hostSelector, shadowSelector, nativeShadow) {
      return "*" + shadowSelector + " {margin: 0px;padding: 0px;}\n.header" + shadowSelector + "{width: 1000px;height: 100px;background:blanchedalmond;}\n.wrapper" + shadowSelector + " {height: 500px;width: 1000px;background: rgb(221, 208, 208);}\n";
    }
    var _implicitStylesheets = [stylesheet];

    function stylesheet$1(hostSelector, shadowSelector, nativeShadow) {
      return "*" + shadowSelector + " {margin: 0px;padding: 0px;user-select: none;}\n.container" + shadowSelector + " {width: 100%;height: 100vh;background: #666;}\n.ch_item" + shadowSelector + "{border: 1px blue solid;position: absolute;width: 150px;height: 100px;background: #88f;font-size: 1px;}\n.pot-left" + shadowSelector + "{left: 98%;}\n.pot" + shadowSelector + "{width: 5px;height: 5px;position: absolute;background: brown;border-radius: 50%;border: 1px orange solid;top: 45%;}\n.pot-right" + shadowSelector + "{left: -2%;}\n.btn" + shadowSelector + "{width: 10px;height: 10px;position: absolute;bottom: 100px;}\nsvg" + shadowSelector + "{background: yellow;position: absolute;width: 20px;min-height: 20px;}\n";
    }
    var _implicitStylesheets$1 = [stylesheet$1];

    function tmpl($api, $cmp, $slotset, $ctx) {
      const {
        d: api_dynamic,
        h: api_element,
        k: api_key,
        b: api_bind,
        i: api_iterator,
        t: api_text,
        f: api_flatten
      } = $api;
      const {
        _m0,
        _m1,
        _m2
      } = $ctx;
      return [api_element("div", {
        classMap: {
          "container": true
        },
        key: 10
      }, api_flatten([api_iterator($cmp.cfeatures, function (cfeature) {
        return api_element("div", {
          classMap: {
            "ch_item": true
          },
          attrs: {
            "jid": cfeature.ch_label.jid
          },
          key: api_key(6, cfeature.ch_icon),
          on: {
            "mousedown": _m0 || ($ctx._m0 = api_bind($cmp.handleonmousedown)),
            "mouseup": _m1 || ($ctx._m1 = api_bind($cmp.handleonmouseup))
          }
        }, [api_element("locationx", {
          styleMap: {
            "display": "none"
          },
          key: 0
        }, [api_dynamic(cfeature.location.X)]), api_element("locationy", {
          styleMap: {
            "display": "none"
          },
          key: 1
        }, [api_dynamic(cfeature.location.Y)]), api_element("div", {
          classMap: {
            "pot": true,
            "pot-left": true
          },
          key: 2
        }, []), api_element("div", {
          classMap: {
            "pot": true,
            "pot-right": true
          },
          key: 3
        }, []), api_dynamic(cfeature.ch_label.jname), api_element("br", {
          key: 4
        }, []), api_dynamic(cfeature.ch_icon), api_element("br", {
          key: 5
        }, [])]);
      }), api_iterator($cmp.cfeatures, function (cfeaturetemp) {
        return api_element("svg", {
          classMap: {
            "d3": true
          },
          attrs: {
            "tj-id": cfeaturetemp.ch_label.jid
          },
          key: api_key(8, cfeaturetemp.ch_icon)
        }, api_iterator(cfeaturetemp.condition.before, function (cd) {
          return [api_dynamic(cd.cnd_id), api_element("path", {
            attrs: {
              "befid": cd.bef_id,
              "d": "M",
              "stroke": "black",
              "fill": "transparent"
            },
            key: api_key(7, cd.cnd_id)
          }, [api_text("{}")])];
        }));
      }), api_element("button", {
        classMap: {
          "btn": true
        },
        key: 9,
        on: {
          "click": _m2 || ($ctx._m2 = api_bind($cmp.handleClick))
        }
      }, [])]))];
    }

    var _tmpl = lwc.registerTemplate(tmpl);
    tmpl.stylesheets = [];

    if (_implicitStylesheets$1) {
      tmpl.stylesheets.push.apply(tmpl.stylesheets, _implicitStylesheets$1);
    }
    tmpl.stylesheetTokens = {
      hostAttribute: "c-ctn_ctn-host",
      shadowAttribute: "c-ctn_ctn"
    };

    const bikes = [{
      unijid: '00001',
      ch_label: {
        'jname': 'name-1',
        'jid': '00001'
      },
      condition: {
        before: [{
          bef_id: '',
          cnd_id: 'adkwjanua18311'
        }],
        time: '0000'
      },
      ch_icon: 'ahhhh000001',
      location: {
        'X': 100,
        'Y': 100
      }
    }, {
      unijid: '00002',
      ch_label: {
        'jname': 'name-2',
        'jid': '00002'
      },
      condition: {
        before: [{
          bef_id: '00001',
          cnd_id: 'adkwjanua1832'
        }]
      },
      ch_icon: 'ahhhh000002',
      location: {
        'X': 350,
        'Y': 250
      }
    }, {
      unijid: '00003',
      ch_label: {
        'jname': 'name-3',
        'jid': '00003'
      },
      condition: {
        before: [{
          bef_id: '00001',
          cnd_id: 'adkwjanua1833'
        }]
      },
      ch_icon: 'ahhhh000003',
      location: {
        'X': '350',
        'Y': '350'
      }
    } // {
    //     unijid:'00004',
    //     ch_label:{'jname':'name-4','jid':'00004'},
    //     condition:{before: [{
    //                             bef_id:'',
    //                             cnd_id: 'adkwjanua1834',
    //                         },]
    //             },
    //     ch_icon: 'ahhhh000004',
    //     location: {'X':'100','Y':'400'},
    // },
    // {
    //     unijid:'00005',
    //     ch_label:{'jname':'name-5','jid':'00005'},                
    //     condition:{before: [{
    //                             bef_id:'',
    //                             cnd_id: 'adkwjanua1835',
    //                         },]
    //             },
    //     ch_icon: 'ahhhh000005',
    //     location: {'X':'100','Y':'500'},
    // },
    ];

    const items_width = parseInt(150);
    const items_height = parseInt(100);
    /**
     * Show an item
     */

    class Ctn extends lwc.LightningElement {
      constructor(...args) {
        super(...args);
        this.label = '';
        this.cfeatures = bikes;
        this.forcusjob = '';
      }

      renderedCallback() {
        // node list
        let ch_items = this.template.querySelectorAll('.ch_item');
        console.log('length:' + ch_items.length);
        console.log('-----------locateContainer------------');
        let mylocMap = new Map();
        let job = {};
        console.log(JSON.stringify(this.cfeatures));

        for (let ind = 0; ind < this.cfeatures.length; ind++) {
          job = this.cfeatures[ind];
          mylocMap.set(job.unijid, job.location);
        }

        for (var [key, value] of mylocMap) {
          console.log(key + ' = ' + value);
        }

        console.log('-----------locateContainer------------');

        for (let ind = 0; ind < ch_items.length; ind++) {
          let thisJob = ch_items[ind];
          let thisNodeLoc = new Map();
          thisNodeLoc.set("X", thisJob.querySelector('locationX').innerHTML);
          thisNodeLoc.set("Y", thisJob.querySelector('locationY').innerHTML);
          thisJob.style.left = thisNodeLoc.get("X") + 'px';
          thisJob.style.top = thisNodeLoc.get("Y") + 'px';
          let thisj_location_x = thisNodeLoc.get("X");
          let thisj_location_y = thisNodeLoc.get("Y");
          let svgboxs = this.template.querySelectorAll('svg.d3');

          for (let ind = 0; ind < svgboxs.length; ind++) {
            console.log('tj-id:' + svgboxs[ind].getAttribute('tj-id'));
            let thisSvg = svgboxs[ind]; // svg style

            let svg_wid, svg_hgt, svg_top, svg_left;
            svg_wid = svg_hgt = svg_top = svg_left = 0;

            if (thisJob.getAttribute('jid') == thisSvg.getAttribute('tj-id')) {
              // // -[node bef node location
              // console.log('svg:'+svgbox[0])
              let paths = thisSvg.querySelectorAll('path');
              console.log('paths:' + paths);

              for (let ind = 0; ind < paths.length; ind++) {
                let thisPath = paths[ind];
                let befid = thisPath.getAttribute('befid');
                console.log('befid:' + befid);

                if (befid == '') {
                  console.log('do nothing');
                  thisPath.style.display = 'none';
                } else {
                  // -[node bef node location
                  console.log('do something');
                  let befj_location_x = mylocMap.get(befid).X;
                  let befj_location_y = mylocMap.get(befid).Y; //************ svg ************/
                  // style

                  let w_temp = Math.abs(thisj_location_x - befj_location_x);
                  let old_svg_wid = svg_wid;
                  let old_svg_hgt = svg_hgt;
                  svg_wid = w_temp < parseInt(items_width) ? w_temp : w_temp - parseInt(items_width);
                  svg_hgt = Math.abs(thisj_location_y - befj_location_y) + parseInt(items_height);
                  svg_wid = old_svg_wid > svg_wid ? old_svg_wid : svg_wid;
                  svg_hgt = old_svg_hgt > svg_hgt ? old_svg_hgt : svg_hgt; // location

                  svg_top = befj_location_y;
                  console.log(parseInt(items_height));
                  console.log(befj_location_y + "+" + parseInt(items_height) / 2);
                  svg_left = befj_location_x + parseInt(items_width); //************ path ************/
                  // let pM = befj_location_x + parseInt(items_width) + " " + befj_location_y + (parseInt(items_height)/2)

                  let pL = svg_wid + ' ' + (Math.abs(thisj_location_y - befj_location_y) + items_height / 2);
                  thisPath.setAttribute('d', 'M0 50' + " L" + pL);
                  console.log('thisPath:' + thisPath.getAttribute('d'));
                }
              }

              thisSvg.style.top = svg_top + 'px';
              thisSvg.style.left = svg_left + 'px';
              thisSvg.style.width = svg_wid + 'px';
              thisSvg.style.height = svg_hgt + 'px';
            }
          }
        }
      }

      handleClick() {
        // console.log('renderedCallback')
        let ctn = this.template.querySelector('svg.d3');
        console.log('ctn:' + ctn); // ctn.appendChild("div")
        // ctn.firstChild.appendChild('<path d="M10 80 Q 95 10 180 80" stroke="black" fill="transparent"></path>')

        console.log(JSON.stringify(this.template.querySelector('svg.d3')));
      }

      handleonmousedown(event) {
        console.log("handleonmousedown");
        let node = event.target;
        let thisSvg = {};
        let svgboxs = this.template.querySelectorAll('svg.d3'); // svg style    

        let svg_wid = '';
        let svg_hgt = '';

        for (let ind = 0; ind < svgboxs.length; ind++) {
          thisSvg = svgboxs[ind];

          if (node.getAttribute('jid') == thisSvg.getAttribute('tj-id')) {
            break;
          }
        } // let node = this.template.querySelector(".ch_item")


        console.log(JSON.stringify("node:" + node)); // let nodectn = event.target.parentNode;

        let nodectn = this.template.querySelector(".container");
        console.log(JSON.stringify("nodectn:" + nodectn));
        let old_evecli_X = event.clientX;
        let old_evecli_Y = event.clientY;
        let disX = 0;
        let disY = 0;
        disX = event.clientX - node.offsetLeft;
        disY = event.clientY - node.offsetTop;
        console.log(JSON.stringify(node.class)); // console.log(JSON.stringify(node.style));

        let old_svg_wid = parseInt(thisSvg.style.width.replace('px', ''));
        let old_svg_hgt = parseInt(thisSvg.style.height.replace('px', ''));

        nodectn.onmousemove = function (event) {
          // console.log("node:" + JSON.stringify(node.style))
          console.log("clientX:" + event.clientX);
          console.log("disX:" + disX);
          node.style.left = event.clientX - disX + 'px';
          node.style.top = event.clientY - disY + 'px';
          console.log('thisSvg.style.width:' + thisSvg.style.width.replace('px', ''));
          svg_wid = +old_svg_wid + (event.clientX - old_evecli_X);
          svg_hgt = +old_svg_hgt + (event.clientY - old_evecli_Y); // thisSvg.style.left = svg_left + 'px'

          thisSvg.style.width = svg_wid + 'px';
          thisSvg.style.height = svg_hgt + 'px';
          let paths = thisSvg.querySelectorAll('path');
          console.log('paths:' + paths);

          for (let ind = 0; ind < paths.length; ind++) {
            let thisPath = paths[ind];
            let befid = thisPath.getAttribute('befid'); // console.log('befid:'+befid)

            if (befid == '') ; else {
              // -[node bef node location
              let p_fr = 'M0 ' + items_height / 2;
              let p_to = 'L' + svg_wid + ' ' + (svg_hgt - 50);
              thisPath.setAttribute('d', p_fr + " " + p_to);
              console.log('p_fr p_to:' + p_fr + '' + p_to); // console.log('thisPath:'+thisPath.getAttribute('d'))
            } // console.log(paths[ind].querySelector('path').innerHTML)

          }
        };
      }

      handleonmouseup(event) {
        let nodectn = this.template.querySelector(".container");
        nodectn.onmousemove = null;
        nodectn.onmouseup = null;
      }

    }

    lwc.registerDecorators(Ctn, {
      publicProps: {
        label: {
          config: 0
        },
        forcusjob: {
          config: 0
        }
      },
      publicMethods: ["renderedCallback"],
      track: {
        cfeatures: 1
      }
    });

    var _cCtn = lwc.registerComponent(Ctn, {
      tmpl: _tmpl
    });

    function tmpl$1($api, $cmp, $slotset, $ctx) {
      const {
        h: api_element,
        k: api_key,
        c: api_custom_element,
        i: api_iterator,
        f: api_flatten
      } = $api;
      return [api_element("div", {
        classMap: {
          "wrapper": true
        },
        key: 2
      }, api_flatten([api_element("div", {
        classMap: {
          "header": true
        },
        key: 0
      }, []), api_iterator($cmp.features, function (feature) {
        return api_custom_element("c-ctn", _cCtn, {
          props: {
            "label": feature.label
          },
          key: api_key(1, feature.label)
        }, []);
      })]))];
    }

    var _tmpl$1 = lwc.registerTemplate(tmpl$1);
    tmpl$1.stylesheets = [];

    if (_implicitStylesheets) {
      tmpl$1.stylesheets.push.apply(tmpl$1.stylesheets, _implicitStylesheets);
    }
    tmpl$1.stylesheetTokens = {
      hostAttribute: "c-app_app-host",
      shadowAttribute: "c-app_app"
    };

    class App extends lwc.LightningElement {
      constructor(...args) {
        super(...args);
        this.title = 'Welcome to Lightning Web Components Playground!';
        this.showFeatures = true;
      }

      /**
       * Getter for the features property
       */
      get features() {
        return [{
          label: '00:00'
        }];
      }

    }

    lwc.registerDecorators(App, {
      track: {
        title: 1,
        showFeatures: 1
      }
    });

    var main = lwc.registerComponent(App, {
      tmpl: _tmpl$1
    });

    registerWireService(lwc.register);

        const element = lwc.createElement('c-app', { is: main, fallback: true });
        document.querySelector('main').appendChild(element);

}(Engine));
