export const bikes = [
            {
                unijid:'00001',
                ch_label:{'jname':'name-1','jid':'00001'},
                condition:{before: [{
                                        bef_id:'',
                                        cnd_id: 'adkwjanua18311',
                                    },],
                            time:'0000'
                        },
                ch_icon: 'ahhhh000001',
                location: {'X':100,'Y':100},
            },
            {
                unijid:'00002',
                ch_label:{'jname':'name-2','jid':'00002'},
                condition:{before: [{
                                        bef_id:'00001',
                                        cnd_id: 'adkwjanua1832',
                                    },]
                        },
                ch_icon: 'ahhhh000002',
                location: {'X':350,'Y':250},

            },
            {
                unijid:'00003',
                ch_label:{'jname':'name-3','jid':'00003'},
                condition:{before: [{
                                        bef_id:'00001',
                                        cnd_id: 'adkwjanua1833',
                                    },]
                        },
                ch_icon: 'ahhhh000003',
                location: {'X':'350','Y':'350'},

            },
            // {
            //     unijid:'00004',
            //     ch_label:{'jname':'name-4','jid':'00004'},
            //     condition:{before: [{
            //                             bef_id:'',
            //                             cnd_id: 'adkwjanua1834',
            //                         },]
            //             },
            //     ch_icon: 'ahhhh000004',
            //     location: {'X':'100','Y':'400'},

            // },
            // {
            //     unijid:'00005',
            //     ch_label:{'jname':'name-5','jid':'00005'},                
            //     condition:{before: [{
            //                             bef_id:'',
            //                             cnd_id: 'adkwjanua1835',
            //                         },]
            //             },
            //     ch_icon: 'ahhhh000005',
            //     location: {'X':'100','Y':'500'},
            // },
        ];