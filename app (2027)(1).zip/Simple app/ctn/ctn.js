import { LightningElement, track, api } from 'lwc';
import { bikes } from 'c/data';


const items_width = parseInt(150);
const items_height = parseInt(100);

/**
 * Show an item
 */
export default class Ctn extends LightningElement {
    @api
    label = '';
    
    @track
    cfeatures = bikes;

    @api
    forcusjob = '';

    @api

    renderedCallback(){
        
        // node list
        let ch_items = this.template.querySelectorAll('.ch_item')
        console.log('length:'+ch_items.length)
        console.log('-----------locateContainer------------')
        let mylocMap = new Map()
        let job = {}

        console.log(JSON.stringify(this.cfeatures))
        for(let ind=0;ind<this.cfeatures.length;ind++){
            job = this.cfeatures[ind]
            mylocMap.set(job.unijid,job.location)
        }
        for (var [key, value] of mylocMap) {console.log(key + ' = ' + value)}
        console.log('-----------locateContainer------------')
        
        for(let ind=0; ind < ch_items.length; ind++){
            let thisJob = ch_items[ind]
            let thisNodeLoc = new Map()            
            thisNodeLoc.set("X",thisJob.querySelector('locationX').innerHTML)  
            thisNodeLoc.set("Y",thisJob.querySelector('locationY').innerHTML)
            thisJob.style.left = thisNodeLoc.get("X") + 'px';
            thisJob.style.top = thisNodeLoc.get("Y") + 'px';
            
            let thisj_location_x = thisNodeLoc.get("X")
            let thisj_location_y = thisNodeLoc.get("Y")

            let svgboxs = this.template.querySelectorAll('svg.d3')
            for(let ind=0; ind < svgboxs.length; ind++){
                console.log('tj-id:'+svgboxs[ind].getAttribute('tj-id'))
                let thisSvg = svgboxs[ind]
                // svg style
                let svg_wid,svg_hgt,svg_top,svg_left
                svg_wid = svg_hgt = svg_top = svg_left = 0
                
                if(thisJob.getAttribute('jid')==thisSvg.getAttribute('tj-id')){
                    // // -[node bef node location
                    // console.log('svg:'+svgbox[0])
                    let paths = thisSvg.querySelectorAll('path')
                    console.log('paths:'+paths)
                    for(let ind=0; ind < paths.length; ind++){
                        let thisPath = paths[ind]
                        let befid = thisPath.getAttribute('befid')
                        console.log('befid:'+befid)
                        if(befid == ''){
                            console.log('do nothing')   
                            thisPath.style.display = 'none' 
                        }else{
                            // -[node bef node location
                            console.log('do something')
                            let befj_location_x = mylocMap.get(befid).X
                            let befj_location_y = mylocMap.get(befid).Y
                            //************ svg ************/
                            // style
                            let w_temp = Math.abs(thisj_location_x - befj_location_x)
                            let old_svg_wid = svg_wid
                            let old_svg_hgt = svg_hgt

                            svg_wid = w_temp < parseInt(items_width) ? w_temp : w_temp - parseInt(items_width)
                            svg_hgt = Math.abs(thisj_location_y - befj_location_y) + parseInt(items_height)

                            svg_wid = old_svg_wid > svg_wid ? old_svg_wid : svg_wid
                            svg_hgt = old_svg_hgt > svg_hgt ? old_svg_hgt : svg_hgt

                            // location
                            svg_top = befj_location_y
                            console.log(parseInt(items_height))
                            console.log(befj_location_y + "+" + (parseInt(items_height) / 2))
                            svg_left = befj_location_x + parseInt(items_width)
                            //************ path ************/
                            // let pM = befj_location_x + parseInt(items_width) + " " + befj_location_y + (parseInt(items_height)/2)
                            let pL = svg_wid + ' ' + (Math.abs(thisj_location_y - befj_location_y) + items_height/2)
                            thisPath.setAttribute('d', 'M0 50' + " L" + pL)
                            console.log('thisPath:'+thisPath.getAttribute('d'))
                            
                        }
                    }

                    thisSvg.style.top = svg_top + 'px'
                    thisSvg.style.left = svg_left + 'px'
                    thisSvg.style.width = svg_wid + 'px'
                    thisSvg.style.height = svg_hgt + 'px'
                }
            }
        
            


        


        }

        


    }


    handleClick(){
        // console.log('renderedCallback')
        let ctn = this.template.querySelector('svg.d3')
        console.log('ctn:'+ctn)
        
        // ctn.appendChild("div")
        // ctn.firstChild.appendChild('<path d="M10 80 Q 95 10 180 80" stroke="black" fill="transparent"></path>')
        console.log(JSON.stringify(this.template.querySelector('svg.d3')))
    }




    handleonmousedown(event){
        console.log("handleonmousedown")

        let node = event.target;
        let thisSvg = {}
        let svgboxs = this.template.querySelectorAll('svg.d3')
        // svg style    
        let svg_wid = ''
        let svg_hgt = ''
        let svg_top = ''
        let svg_left = ''
        for(let ind=0; ind < svgboxs.length; ind++){
            thisSvg = svgboxs[ind]
            if(node.getAttribute('jid')==thisSvg.getAttribute('tj-id')){
                break;
            }
        }
        
        
        // let node = this.template.querySelector(".ch_item")
        console.log(JSON.stringify("node:" + node));
        // let nodectn = event.target.parentNode;
        let nodectn = this.template.querySelector(".container")
        console.log(JSON.stringify("nodectn:" + nodectn));

        let old_evecli_X = event.clientX
        let old_evecli_Y = event.clientY
        let disX = 0;
        let disY = 0;

        disX=event.clientX-node.offsetLeft;
        disY=event.clientY-node.offsetTop;

        console.log(JSON.stringify(node.class));
        // console.log(JSON.stringify(node.style));

        let old_svg_wid = parseInt(thisSvg.style.width.replace('px',''))
        let old_svg_hgt = parseInt(thisSvg.style.height.replace('px',''))

        nodectn.onmousemove = function(event){
            
            // console.log("node:" + JSON.stringify(node.style))
            console.log("clientX:"+event.clientX);
            console.log("disX:"+ disX);

            node.style.left = event.clientX-disX + 'px';
            node.style.top = event.clientY-disY + 'px';

            console.log('thisSvg.style.width:'+thisSvg.style.width.replace('px',''))
            
            svg_wid = + old_svg_wid + (event.clientX - old_evecli_X)
            svg_hgt = + old_svg_hgt + (event.clientY - old_evecli_Y)
            // thisSvg.style.left = svg_left + 'px'
            thisSvg.style.width = svg_wid + 'px'
            thisSvg.style.height = svg_hgt + 'px'
            
            let paths = thisSvg.querySelectorAll('path')
            console.log('paths:'+paths)
            for(let ind=0; ind < paths.length; ind++){
                let thisPath = paths[ind]
                let befid = thisPath.getAttribute('befid')
                // console.log('befid:'+befid)
                if(befid == ''){
                    // console.log('do nothing')   
                    // thisPath.style.display = 'none' 
                }else{
                    // -[node bef node location
                    
                    let p_fr = 'M0 '+ items_height/2
                    let p_to = 'L' + svg_wid + ' ' + (svg_hgt - 50)
                    thisPath.setAttribute('d', p_fr + " " + p_to)
                    console.log('p_fr p_to:'+p_fr+''+p_to)
                    // console.log('thisPath:'+thisPath.getAttribute('d'))


                }
                    // console.log(paths[ind].querySelector('path').innerHTML)
        
            }
        }
    }
    handleonmouseup(event){
        let nodectn = this.template.querySelector(".container")
        nodectn.onmousemove = null
        nodectn.onmouseup = null
    }


}
